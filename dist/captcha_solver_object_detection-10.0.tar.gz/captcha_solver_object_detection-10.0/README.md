# Captcha Object Detection 

A package that uses object detection to solve digit captchas
